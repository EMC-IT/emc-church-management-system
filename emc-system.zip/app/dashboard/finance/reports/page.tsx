'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/ui/page-header';
import { StatCard } from '@/components/ui/stat-card';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText, 
  Download, 
  TrendingUp, 
  TrendingDown,
  BadgeCent,
  Calendar,
  BarChart3,
  PieChart,
  Eye,
  Filter,
  Wallet,
  Receipt,
  Package,
  ArrowRight,
  Heart,
  Target,
  Building
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, Label } from 'recharts';
import { 
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartConfig
} from '@/components/ui/chart';

const financialSummary = {
  totalIncome: 285000,
  totalExpenses: 245000,
  netIncome: 40000,
  totalGiving: 270000,
  budgetUtilization: 87.5,
  assetValue: 1250000,
  growthRate: 12.5,
  previousPeriod: {
    totalIncome: 254000,
    totalExpenses: 220000,
    netIncome: 34000,
    totalGiving: 245000,
    budgetUtilization: 82.3,
    assetValue: 1180000,
  }
};

const monthlyData = [
  { month: 'Jan', income: 45000, expenses: 38000, net: 7000 },
  { month: 'Feb', income: 48000, expenses: 41000, net: 7000 },
  { month: 'Mar', income: 52000, expenses: 44000, net: 8000 },
  { month: 'Apr', income: 47000, expenses: 40000, net: 7000 },
  { month: 'May', income: 51000, expenses: 42000, net: 9000 },
  { month: 'Jun', income: 42000, expenses: 40000, net: 2000 },
];

const incomeBreakdown = [
  { category: 'Tithes', amount: 180000, percentage: 63.2, color: '#2E8CB0' },
  { category: 'Offerings', amount: 65000, percentage: 22.8, color: '#C49831' },
  { category: 'Special Donations', amount: 25000, percentage: 8.8, color: '#A2CD5E' },
  { category: 'Fundraising', amount: 15000, percentage: 5.3, color: '#E74C3C' },
];

const expenseBreakdown = [
  { category: 'Salaries & Benefits', amount: 120000, percentage: 49.0, color: '#2E8CB0' },
  { category: 'Facilities & Utilities', amount: 45000, percentage: 18.4, color: '#C49831' },
  { category: 'Missions & Outreach', amount: 35000, percentage: 14.3, color: '#A2CD5E' },
  { category: 'Ministry Programs', amount: 25000, percentage: 10.2, color: '#E74C3C' },
  { category: 'Administration', amount: 20000, percentage: 8.2, color: '#9B59B6' },
];

const departmentReports = [
  {
    id: '1',
    department: 'Worship Ministry',
    budget: 15000,
    spent: 12500,
    income: 8000,
    variance: -4500,
    status: 'On Track',
  },
  {
    id: '2',
    department: 'Youth Ministry',
    budget: 10000,
    spent: 8200,
    income: 5000,
    variance: -3200,
    status: 'On Track',
  },
  {
    id: '3',
    department: 'Missions',
    budget: 25000,
    spent: 23800,
    income: 15000,
    variance: -8800,
    status: 'Over Budget',
  },
  {
    id: '4',
    department: 'Facilities',
    budget: 20000,
    spent: 18500,
    income: 2000,
    variance: -16500,
    status: 'On Track',
  },
];

// Chart configurations
const monthlyChartConfig = {
  income: {
    label: 'Income',
    color: 'hsl(var(--chart-1))',
  },
  expenses: {
    label: 'Expenses',
    color: 'hsl(var(--chart-2))',
  },
  net: {
    label: 'Net',
    color: 'hsl(var(--chart-3))',
  },
} satisfies ChartConfig;

const incomeChartConfig = {
  amount: {
    label: 'Amount',
  },
} satisfies ChartConfig;

const expenseChartConfig = {
  amount: {
    label: 'Amount',
  },
} satisfies ChartConfig;

const quickLinks = [
  {
    title: 'Income Reports',
    description: 'Source analysis, trends, and monthly breakdown',
    icon: TrendingUp,
    href: '/dashboard/finance/reports/income',
    color: 'bg-green-500/10 text-green-600',
  },
  {
    title: 'Expense Reports',
    description: 'Category and department expense analysis',
    icon: Receipt,
    href: '/dashboard/finance/reports/expenses',
    color: 'bg-red-500/10 text-red-600',
  },
  {
    title: 'Giving Reports',
    description: 'All giving categories and donor analysis',
    icon: Heart,
    href: '/dashboard/finance/reports/giving',
    color: 'bg-pink-500/10 text-pink-600',
  },
  {
    title: 'Tithes & Offerings',
    description: 'Specific tithes and offerings reports',
    icon: Wallet,
    href: '/dashboard/finance/reports/tithes-offerings',
    color: 'bg-blue-500/10 text-blue-600',
  },
  {
    title: 'Budget Reports',
    description: 'Planned vs actual budget analysis',
    icon: Target,
    href: '/dashboard/finance/reports/budgets',
    color: 'bg-purple-500/10 text-purple-600',
  },
  {
    title: 'Asset Reports',
    description: 'Value, depreciation, and maintenance costs',
    icon: Package,
    href: '/dashboard/finance/reports/assets',
    color: 'bg-orange-500/10 text-orange-600',
  },
  {
    title: 'Comparison Reports',
    description: 'Income vs Expenses and Year-to-Year trends',
    icon: BarChart3,
    href: '/dashboard/finance/reports/comparisons',
    color: 'bg-indigo-500/10 text-indigo-600',
  },
];

const availableReports = [
  {
    id: '1',
    name: 'Monthly Financial Summary',
    description: 'Complete overview of income, expenses, and net position',
    type: 'Summary',
    period: 'Monthly',
    lastGenerated: '2024-01-21',
  },
  {
    id: '2',
    name: 'Donor Contribution Report',
    description: 'Individual and family giving patterns and totals',
    type: 'Giving',
    period: 'Quarterly',
    lastGenerated: '2024-01-15',
  },
  {
    id: '3',
    name: 'Budget vs Actual Analysis',
    description: 'Variance analysis across all departments and categories',
    type: 'Budget',
    period: 'Monthly',
    lastGenerated: '2024-01-20',
  },
  {
    id: '4',
    name: 'Tax Deduction Statements',
    description: 'Annual giving statements for tax purposes',
    type: 'Tax',
    period: 'Annual',
    lastGenerated: '2024-01-01',
  },
  {
    id: '5',
    name: 'Cash Flow Projection',
    description: 'Future cash flow analysis and projections',
    type: 'Projection',
    period: 'Quarterly',
    lastGenerated: '2024-01-18',
  },
];

export default function ReportsPage() {
  const router = useRouter();
  const [selectedPeriod, setSelectedPeriod] = useState('current-quarter');
  const [activeTab, setActiveTab] = useState('overview');

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'on track': return 'primary';
      case 'over budget': return 'danger';
      case 'under budget': return 'neutral';
      default: return 'primary';
    }
  };

  const getReportTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'summary': return 'primary';
      case 'giving': return 'neutral';
      case 'budget': return 'neutral';
      case 'tax': return 'danger';
      case 'projection': return 'primary';
      default: return 'primary';
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Financial Reports"
        actions={
          <>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current-month">Current Month</SelectItem>
                <SelectItem value="current-quarter">Current Quarter</SelectItem>
                <SelectItem value="current-year">Current Year</SelectItem>
                <SelectItem value="last-quarter">Last Quarter</SelectItem>
                <SelectItem value="last-year">Last Year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Advanced Filters
            </Button>
          </>
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Financial Overview</TabsTrigger>
          <TabsTrigger value="income">Income Analysis</TabsTrigger>
          <TabsTrigger value="expenses">Expense Analysis</TabsTrigger>
          <TabsTrigger value="reports">Report Library</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Key Metrics */}
          <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Income</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₵{financialSummary.totalIncome.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    +₵{(financialSummary.totalIncome - financialSummary.previousPeriod.totalIncome).toLocaleString()}
                  </span> from last period
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₵{financialSummary.totalExpenses.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-red-600">
                    +₵{(financialSummary.totalExpenses - financialSummary.previousPeriod.totalExpenses).toLocaleString()}
                  </span> from last period
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Net Income</CardTitle>
                <BadgeCent className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  ₵{financialSummary.netIncome.toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    +₵{(financialSummary.netIncome - financialSummary.previousPeriod.netIncome).toLocaleString()}
                  </span> from last period
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Growth Rate</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  +{financialSummary.growthRate}%
                </div>
                <p className="text-xs text-muted-foreground">Year over year</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Giving</CardTitle>
                <Heart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₵{financialSummary.totalGiving.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    +₵{(financialSummary.totalGiving - financialSummary.previousPeriod.totalGiving).toLocaleString()}
                  </span> from last period
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Budget Utilization</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{financialSummary.budgetUtilization}%</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    +{(financialSummary.budgetUtilization - financialSummary.previousPeriod.budgetUtilization).toFixed(1)}%
                  </span> from last period
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Asset Value</CardTitle>
                <Building className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₵{financialSummary.assetValue.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    +₵{(financialSummary.assetValue - financialSummary.previousPeriod.assetValue).toLocaleString()}
                  </span> from last period
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle>Monthly Financial Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={monthlyChartConfig} className="h-[300px] w-full">
                  <LineChart data={monthlyData} margin={{ left: 12, right: 12 }}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      className="text-xs"
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      className="text-xs"
                    />
                    <ChartTooltip 
                      cursor={{ stroke: 'hsl(var(--muted))', strokeWidth: 1 }}
                      content={<ChartTooltipContent indicator="line" />} 
                    />
                    <ChartLegend content={<ChartLegendContent />} />
                    <Line 
                      type="monotone" 
                      dataKey="income" 
                      stroke="hsl(var(--chart-1))" 
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="expenses" 
                      stroke="hsl(var(--chart-2))" 
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="net" 
                      stroke="hsl(var(--chart-3))" 
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Department Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {departmentReports.map((dept) => (
                    <div key={dept.id} className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{dept.department}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm text-muted-foreground">
                              ₵{dept.spent.toLocaleString()} / ₵{dept.budget.toLocaleString()}
                            </span>
                            <Badge variant={getStatusColor(dept.status)}>
                              {dept.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Links */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Links</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {quickLinks.map((link) => {
                  const IconComponent = link.icon;
                  return (
                    <Card 
                      key={link.href} 
                      className="hover:shadow-lg transition-all duration-200 cursor-pointer group"
                      onClick={() => router.push(link.href)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className={`p-2 rounded-lg ${link.color}`}>
                            <IconComponent className="h-5 w-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-sm group-hover:text-brand-primary transition-colors">
                                {link.title}
                              </h3>
                              <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-brand-primary transition-colors" />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {link.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="income" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle>Income Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={incomeChartConfig} className="h-[300px] w-full">
                  <RechartsPieChart>
                    <ChartTooltip 
                      cursor={false}
                      content={<ChartTooltipContent hideLabel />} 
                    />
                    <Pie
                      data={incomeBreakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} ${percentage}%`}
                      outerRadius={100}
                      dataKey="amount"
                      strokeWidth={2}
                    >
                      {incomeBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="hsl(var(--background))" />
                      ))}
                    </Pie>
                  </RechartsPieChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Income Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {incomeBreakdown.map((item) => (
                    <div key={item.category} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="font-medium">{item.category}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">₵{item.amount.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">{item.percentage}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle>Expense Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={expenseChartConfig} className="h-[300px] w-full">
                  <RechartsPieChart>
                    <ChartTooltip 
                      cursor={false}
                      content={<ChartTooltipContent hideLabel />} 
                    />
                    <Pie
                      data={expenseBreakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} ${percentage}%`}
                      outerRadius={100}
                      dataKey="amount"
                      strokeWidth={2}
                    >
                      {expenseBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="hsl(var(--background))" />
                      ))}
                    </Pie>
                  </RechartsPieChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Expense Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {expenseBreakdown.map((item) => (
                    <div key={item.category} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="font-medium">{item.category}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">₵{item.amount.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">{item.percentage}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Available Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {availableReports.map((report) => (
                  <Card key={report.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="text-base">{report.name}</CardTitle>
                          <Badge variant={getReportTypeColor(report.type)}>
                            {report.type}
                          </Badge>
                        </div>
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground">{report.description}</p>
                      
                      <div className="text-sm">
                        <div className="flex justify-between">
                          <span>Period:</span>
                          <span className="font-medium">{report.period}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Last Generated:</span>
                          <span className="font-medium">{new Date(report.lastGenerated).toLocaleDateString()}</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="mr-2 h-4 w-4" />
                          Preview
                        </Button>
                        <Button size="sm" className="flex-1">
                          <Download className="mr-2 h-4 w-4" />
                          Generate
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}