'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/ui/page-header';
import { StatCard } from '@/components/ui/stat-card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Target, 
  Plus, 
  Search, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Edit,
  Trash2,
  Download,
  BadgeCent,
  Calendar,
  Wallet,
  BarChart3,
  Tag,
  FileText,
  Users,
  ArrowRight,
  Eye
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent, ChartConfig } from '@/components/ui/chart';
import { LazySection } from '@/components/ui/lazy-section';
import { LazyLoader } from '@/components/ui/lazy-loader';

const budgets = [
  {
    id: '1',
    name: 'Worship Ministry',
    department: 'Worship',
    amount: 15000,
    spent: 12500,
    period: '2024 Q1',
    status: 'Active',
    owner: 'Music Director',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    description: 'Equipment, sound system maintenance, and worship materials',
  },
  {
    id: '2',
    name: 'Youth Ministry',
    department: 'Youth',
    amount: 10000,
    spent: 8200,
    period: '2024 Q1',
    status: 'Active',
    owner: 'Youth Pastor',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    description: 'Youth events, camps, and educational materials',
  },
  {
    id: '3',
    name: 'Missions & Outreach',
    department: 'Missions',
    amount: 25000,
    spent: 23800,
    period: '2024 Q1',
    status: 'Exceeded',
    owner: 'Missions Director',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    description: 'Local and international missions, community outreach',
  },
  {
    id: '4',
    name: 'Facilities & Maintenance',
    department: 'Facilities',
    amount: 20000,
    spent: 18500,
    period: '2024 Q1',
    status: 'Active',
    owner: 'Facilities Manager',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    description: 'Building maintenance, utilities, and repairs',
  },
  {
    id: '5',
    name: 'Children Ministry',
    department: 'Children',
    amount: 8000,
    spent: 5200,
    period: '2024 Q1',
    status: 'Active',
    owner: 'Children Director',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    description: 'Sunday school materials, children events, and activities',
  },
];

const budgetTrends = [
  { month: 'Jan', allocated: 78000, spent: 65000 },
  { month: 'Feb', allocated: 78000, spent: 72000 },
  { month: 'Mar', allocated: 78000, spent: 68000 },
  { month: 'Apr', allocated: 82000, spent: 75000 },
  { month: 'May', allocated: 82000, spent: 78000 },
  { month: 'Jun', allocated: 82000, spent: 80000 },
];

const departmentSpending = [
  { department: 'Worship', budget: 15000, spent: 12500 },
  { department: 'Youth', budget: 10000, spent: 8200 },
  { department: 'Missions', budget: 25000, spent: 23800 },
  { department: 'Facilities', budget: 20000, spent: 18500 },
  { department: 'Children', budget: 8000, spent: 5200 },
];

// Quick Actions for budget management
const quickActions = [
  {
    title: 'Create Budget',
    description: 'Set up new budget',
    href: '/dashboard/finance/budgets/add',
    icon: Plus,
    color: 'bg-brand-primary'
  },
  {
    title: 'Manage Categories',
    description: 'Budget categories',
    href: '/dashboard/finance/budgets/categories',
    icon: Tag,
    color: 'bg-brand-secondary'
  },
  {
    title: 'View Reports',
    description: 'Budget analytics',
    href: '/dashboard/finance/budgets/reports',
    icon: BarChart3,
    color: 'bg-brand-accent'
  },
  {
    title: 'Allocate Funds',
    description: 'Manage allocations',
    href: '/dashboard/finance/budgets/allocations',
    icon: Users,
    color: 'bg-brand-success'
  }
];

// Chart configurations
const budgetTrendsConfig = {
  allocated: { label: 'Allocated', color: 'hsl(var(--chart-1))' },
  spent: { label: 'Spent', color: 'hsl(var(--chart-2))' },
} satisfies ChartConfig;

const departmentConfig = {
  budget: { label: 'Budget', color: 'hsl(var(--chart-1))' },
  spent: { label: 'Spent', color: 'hsl(var(--chart-2))' },
} satisfies ChartConfig;

export default function BudgetsPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [budgetToDelete, setBudgetToDelete] = useState<any>(null);

  const filteredBudgets = budgets.filter(budget => {
    const matchesSearch = budget.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         budget.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || budget.status.toLowerCase() === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active': return 'primary';
      case 'completed': return 'neutral';
      case 'exceeded': return 'danger';
      case 'draft': return 'neutral';
      default: return 'primary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active': return <CheckCircle className="h-4 w-4" />;
      case 'exceeded': return <AlertTriangle className="h-4 w-4" />;
      default: return null;
    }
  };

  const getUtilizationColor = (percentage: number) => {
    if (percentage > 100) return 'text-red-600';
    if (percentage > 90) return 'text-yellow-600';
    return 'text-green-600';
  };

  const handleDeleteBudget = (budget: any) => {
    // In a real app, this would call an API
    console.log('Deleting budget:', budget.name);
    // For now, just show a success message or update local state
    setBudgetToDelete(null);
  };

  const totalBudget = budgets.reduce((sum, budget) => sum + budget.amount, 0);
  const totalSpent = budgets.reduce((sum, budget) => sum + budget.spent, 0);
  const utilizationRate = Math.round((totalSpent / totalBudget) * 100);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Budget Management"
        actions={
          <>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Budgets
            </Button>
            <Button asChild>
              <Link href="/dashboard/finance/budgets/add">
                <Plus className="mr-2 h-4 w-4" />
                Create Budget
              </Link>
            </Button>
          </>
        }
      />

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard
          title="Total Budget"
          value={`₵${totalBudget.toLocaleString()}`}
          icon={Target}
          accent="primary"
          description="Allocated this quarter"
        />

        <StatCard
          title="Total Spent"
          value={`₵${totalSpent.toLocaleString()}`}
          icon={BadgeCent}
          accent="secondary"
          description="Spent so far"
        />

        <StatCard
          title="Remaining"
          value={`₵${(totalBudget - totalSpent).toLocaleString()}`}
          icon={Calendar}
          accent="success"
          description="Available to spend"
        />

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilization Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ₵{getUtilizationColor(utilizationRate)}`}>
              {utilizationRate}%
            </div>
            <Progress value={utilizationRate} className="mt-2" />
          </CardContent>
        </Card>
      </div>

        {/* Quick Actions */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Quick Actions</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {quickActions.map((action, index) => (
              <Card key={index} className="group hover:shadow-md transition-shadow cursor-pointer">
                <Link href={action.href} className="block p-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${action.color}`}>
                      <action.icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium group-hover:text-brand-primary transition-colors">
                        {action.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {action.description}
                      </p>
                    </div>
                  </div>
                </Link>
              </Card>
            ))}
          </div>
        </div>

        {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Budget vs Spending Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={budgetTrendsConfig} className="h-[300px] w-full">
              <LineChart data={budgetTrends} margin={{ left: 12, right: 12 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="month" 
                  tickLine={false} 
                  axisLine={false} 
                  tickMargin={8}
                  className="text-xs"
                />
                <YAxis 
                  tickLine={false} 
                  axisLine={false} 
                  tickMargin={8}
                  className="text-xs"
                />
                <ChartTooltip 
                  cursor={{ stroke: 'hsl(var(--muted))', strokeWidth: 1 }}
                  content={<ChartTooltipContent indicator="line" />} 
                />
                <ChartLegend content={<ChartLegendContent />} />
                <Line 
                  type="monotone" 
                  dataKey="allocated" 
                  stroke="hsl(var(--chart-1))" 
                  strokeWidth={2} 
                  dot={{ fill: 'hsl(var(--chart-1))' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="spent" 
                  stroke="hsl(var(--chart-2))" 
                  strokeWidth={2}
                  dot={{ fill: 'hsl(var(--chart-2))' }}
                />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Department Budget Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={departmentConfig} className="h-[300px] w-full">
              <BarChart data={departmentSpending} margin={{ left: 12, right: 12 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="department" 
                  tickLine={false} 
                  axisLine={false} 
                  tickMargin={8}
                  className="text-xs"
                />
                <YAxis 
                  tickLine={false} 
                  axisLine={false} 
                  tickMargin={8}
                  className="text-xs"
                />
                <ChartTooltip 
                  cursor={{ fill: 'hsl(var(--muted)/0.2)' }}
                  content={<ChartTooltipContent indicator="dot" />} 
                />
                <ChartLegend content={<ChartLegendContent />} />
                <Bar 
                  dataKey="budget" 
                  fill="hsl(var(--chart-1))" 
                  radius={[8, 8, 0, 0]}
                />
                <Bar 
                  dataKey="spent" 
                  fill="hsl(var(--chart-2))" 
                  radius={[8, 8, 0, 0]}
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Budget Table */}
      <Card>
        <CardHeader>
          <CardTitle>Budget Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search budgets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="exceeded">Exceeded</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Budget Name</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Spent</TableHead>
                <TableHead>Utilization</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBudgets.map((budget) => {
                const utilization = Math.round((budget.spent / budget.amount) * 100);
                
                return (
                  <TableRow 
                    key={budget.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => router.push(`/dashboard/finance/budgets/${budget.id}`)}
                  >
                    <TableCell>
                      <div>
                        <p className="font-medium">{budget.name}</p>
                        <p className="text-sm text-muted-foreground">{budget.period}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="neutral">{budget.department}</Badge>
                    </TableCell>
                    <TableCell className="font-semibold">
                      ₵{budget.amount.toLocaleString()}
                    </TableCell>
                    <TableCell className="font-semibold text-orange-600">
                      ₵{budget.spent.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className={getUtilizationColor(utilization)}>
                            {utilization}%
                          </span>
                        </div>
                        <Progress value={utilization} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(budget.status)} className="flex items-center space-x-1 w-fit">
                        {getStatusIcon(budget.status)}
                        <span>{budget.status}</span>
                      </Badge>
                    </TableCell>
                    <TableCell>{budget.owner}</TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <div className="flex space-x-1">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => router.push(`/dashboard/finance/budgets/${budget.id}`)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => router.push(`/dashboard/finance/budgets/${budget.id}/edit`)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => setBudgetToDelete(budget)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Budget</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete the budget "{budgetToDelete?.name}"? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel onClick={() => setBudgetToDelete(null)}>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => {
                                  if (budgetToDelete) {
                                    handleDeleteBudget(budgetToDelete);
                                  }
                                }}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}